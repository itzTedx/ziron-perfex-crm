# Nucleo Micro Bold Essential
Discover our Nucleo Micro Bold Essential Icons – a carefully curated subset of the broader Nucleo Micro Bold icon library. These free icons are offered in SVG format. 

Explore the entire Nucleo icon library:
https://nucleoapp.com/


## License
https://nucleoapp.com/license